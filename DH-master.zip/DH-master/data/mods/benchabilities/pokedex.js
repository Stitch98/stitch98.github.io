'use strict';

/**@type {{[k: string]: TemplateData}} */
let BattlePokedex = {
victini: {
		inherit: true,
		//abilities: {0: "Victory Star", S: "Confidence Boost"},
	// https://github.com/Spandamn/DH/blob/master/data/mods/benchabilities/scripts.js#L31
	},
};

exports.BattlePokedex = BattlePokedex;
