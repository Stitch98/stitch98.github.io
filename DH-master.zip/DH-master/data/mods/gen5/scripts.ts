export const BattleScripts: ModdedBattleScriptsData = {
	inherit: 'gen6',
	gen: 5,
};
