export const BattleFormatsData: {[k: string]: ModdedSpeciesFormatsData} = {
	goodraflame: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// electivirekungfu: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	flygonbuzz: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// banetteblademaster: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	// banettemegablademaster: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	// kingdracamo: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	vikavoltmigale: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// typhlosioncinder: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	flareonocean: {
		tier: "OU",
		doublesTier: "DOU",
	},
	laprasangry: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// exploudmeow: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	butterfreearmor: {
		tier: "OU",
		doublesTier: "DOU",
	},
	espeondusk: {
		tier: "OU",
		doublesTier: "DOU",
	},
	avaluggshield: {
		tier: "OU",
		doublesTier: "DOU",
	},
	dusclopsgastric: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// delphoxlazy: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	// lurantisnut: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	sylveonprotector: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// skarmoryprimordial: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	// infernapebugout: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	// breloomluau: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	leafeoncutlass: {
		tier: "OU",
		doublesTier: "DOU",
	},
	froslassgunwoman: {
		tier: "OU",
		doublesTier: "DOU",
	},
	// dodriomystical: {
		// tier: "OU",
		// doublesTier: "DOU",
	// },
	mantinespiny: {
		tier: "OU",
		doublesTier: "DOU",
	},
	rapidashgalarmeow: {
		tier: "OU",
		doublesTier: "DOU",
	},
	mrrimespoon: {
		tier: "OU",
		doublesTier: "DOU",
	},
	thievulbananas: {
		tier: "OU",
		doublesTier: "DOU",
	},
	stonjournercastle: {
		tier: "OU",
		doublesTier: "DOU",
	},
	copperajahforge: {
		tier: "OU",
		doublesTier: "DOU",
	},
	grapploctray: {
		tier: "OU",
		doublesTier: "DOU",
	},
	appletunburned: {
		tier: "OU",
		doublesTier: "DOU",
	},
	vespiquenterra: {
		tier: "OU",
		doublesTier: "DOU",
	},
	cursolashock: {
		tier: "OU",
		doublesTier: "DOU",
	},
	machamplucha: {
		tier: "OU",
		doublesTier: "DOU",
	},
	roseradescarfed: {
		tier: "OU",
		doublesTier: "DOU",
	},
};