'use strict';

exports.BattleFormatsData = { //
/*pikachulibre: {
		randomBattleMoves: ["volttackle", "knockoff", "extremespeed", "imprisonedstrike"],
		tier: "OU",
	},*/
porygonz: {
		randomBattleMoves: ["thunderbolt", "shadowball", "icebeam", "psyshock"],
		tier: "OU",
	},
  gastrodon: {
		randomBattleMoves: ["scald", "earthpower", "recover", "toxic"],
		tier: "OU",
	},
	pikachu: {
		randomBattleMoves: ["volttackle", "knockoff", "extremespeed", "imprisonedstrike"],
		tier: "OU",
	},
	raichu: {
		randomBattleMoves: ["volttackle", "knockoff", "extremespeed", "imprisonedstrike"],
		tier: "OU",
	},
	pichu: {
		randomBattleMoves: ["volttackle", "knockoff", "extremespeed", "imprisonedstrike"],
		tier: "OU",
	},
	heracross: {
		randomBattleMoves: ["volttackle", "knockoff", "extremespeed", "imprisonedstrike"],
		tier: "OU",
	},
};
