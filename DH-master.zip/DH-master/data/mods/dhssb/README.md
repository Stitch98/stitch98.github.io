![Dragon Heaven Super Staff Bros](http://i1279.photobucket.com/albums/y523/textcraft/Nov%202016%20-%202/6e4b25c68c3b6b52614bd0164846292e5edbb3eeda39a3ee5e6b4b0d3255bfef95601890afd80709da39a3ee5e6b4b0d3255bfef95601890afd80709c896_zpsj2inbsfi.png)

#                                        Dragon Heaven Super Staff Bros sets
========================================================================
### XpRienzo ☑-☑

![XpRienzo](http://www.smogon.com/dex/media/sprites/xy/reshiram.gif)

Reshiram @ Charcoal 

Ability: Adaptability 

EVs: 252 SpA / 252 Spe / 4 SpD 

Timid Nature   
- Core Enforcer  
- Volt Switch  
- Psystrike
- Bleh Flame

**Bleh Flame:** Accuracy: 100 Base Power: 100 | Special Attack| 40% chance to raise the user's Attack, Defense, Special Attack, Special Defense, and Speed by 1 stage

### Ransei
Rayquaza-Mega @ Life Orb

Ability: Wonder Breaker 

EVs: 248 HP / 252 Atk/ 252 SpA / 252 Spe

Mild Nature 
- Dragon Ascent  
- Tail Glow  
- Draco Meteor  
- Legend's Ambition 

**Legend's Ambition:** (Power: 0 +10 for every typing that exists. So basically 180), Attack: Special, Accuracy: 100%| Type: Dragon| PP: 8| Priority: 1| Secondary effects: Super effective to all Pokemon including Fairy-type Pokemon. User loses 50% of their HP on use and speed is decreased by 2x making it 0.5

**Wonder Breaker:** - This Pokemon's moves and their effects ignore the Abilities and Stat Boosts of other Pokemon, Status inflicted from other Pokemon, and cannot have its stats lowered.

### Spandan
![Spandan](http://www.smogon.com/dex/media/sprites/xy/salamence-mega.gif)

Salamence-Mega @ Salamencite

Ability: Multiscale then Aerilate

EVs: 252 HP / 252 Atk / 252 Def / 252 SpA / 252 SpD / 252 Spe
- Shift Gear  
- Boomburst  
- Extreme Speed  
- Yo Mamma Joke
- Total Annhiliation (Z-Move)

**Yo Mamma Joke:** +1 Priority| Physical Move| 180 Base Power| User recovers 75% of the damage dealt| PP:10| Flying Type

### Mareanie
![Mareanie](http://www.smogon.com/dex/media/sprites/xy/mareanie.gif)

Mareanie @ Spandan's Phone

Ability: Corrosion

EVs: 252 HP / 252 Atk / 252 Def / 252 SpA / 252 SpD / 252 Spe
- Toxic  
- Get HP Code - Restores HP.  
- Get Boost Code - Boosts stats if Mareanie is holding Spandan's Phone 
- Here's my phone <3 - Mareanie gives its phone to the opponent.
- I'm Toxic You're Slippin Under (Z-Move)

**I'm Toxic You're Slippin Under** +3 Priority| Physical Move| 250 Base Power| Uses the target's attack to deal sum Poison damage.| PP:10| Poison Type

**Spandan's Phone**: Special Item.
If the user is not one of Spandan's alts, the Phone will self destruct, dealing one fourth of the Pokemon's HP as damage.
If the user is Mareanie: 
- Get HP Code restores 75%
- Get Boost Code boosts Defense, Special Defense and Speed by one
- The Z-Move is usable
- On activation, Spandan's alts are boosted (+2 in Defenses)


### Snaquaza 
Lapras @ Leftovers

Ability: Shell Armor Clone

EVs: 252 HP / 252 Atk / 252 Def / 252 SpA / 252 SpD / 252 Spe

Serious Nature
- Ice Beam  
- Ancient Power  
- Surf  
- Ice Shard

Shell Armor Clone:

### Snaq
Magikarp @ Air Balloon

Ability: Parting Shot Spam
- Splash

Paring Shot Spam: Uses Parting Shot on switch in

### Spookuaza
~~Pumpkaboo~~ Phantump @ Eviolite 

Ability: Phantom Guard

EVs: 252 HP / 4 Atk / 252 Def  
Impish Nature  
- Destiny Bond  
- Will-O-Wisp  
- Horn Leech
- Necromancy

Phantom Guard:

Necromancy:

### charizard8888  
![charizard8888](http://www.smogon.com/dex/media/sprites/xy/charizard-mega-x.gif)

Mega Charizard X @ **Firium Z**

Ability: Refrigerate

EVs: 252 Atk / 4 SpD / 252 Spe  

Jolly Nature  
- Fake Out
- Extreme Speed
- Earthquake 
- gg m8  

**ggm8:**  Dragon Type | Physical move | 190 Base Power | Accuracy: 100 |PP: 15| Additional Effect : 50 % chance to Burn the Target and 80 % chance to increase the speed by 1 Stage| Animation: Like V-Create|Priority: 0|

### PI EddyChomp
![PI EddyChomp](http://www.smogon.com/dex/media/sprites/xy/garchomp-mega.gif)  
Mega Garchomp @ Focus Sash 

Ability: Epic Claws  

EVs: 252 Atk / 4 Def / 252 Spe  
Adamant Nature  
- Precipice Blades  
- Dragon Claw  
- Sacred Fire
- GARCHOMP EPICNESS

Epic Claws: Description will be added soon (the mon is getting buffed)

GARCHOMP EPICNESS:  ^

### The God of Haxorus 
Haxorus @ Life Orb

Ability: Blessed Hax

EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Iron Head
- Diamond Storm
- Sacred Fire
- Haxing Rage 

Haxing Rage Power: 130 Base Power | Physical | Dragon Type | Animation Outrage | 40% chance to confuse the target, 40% chance to raise user's attack by 1 stage, drains 50% of the damage dealt.

Blessed Hax Serene Grace + Speed Boost + Raises Defense and Special Defense by 1 upon entry.

### Hydrostatics
Palkia @ Leftovers  

Ability: Pressure + Mold Breaker

EVs: 252 SpA / 252 Spe / 4 HP

Modest Nature
- Core Enforcer  
- Hydro Pump  
- Flash Cannon  
- Space Compress

Space Compress: Increases The SpA, sp def and evasion of the user| decreases the attack, def and speed of the opponent's pokemon| 
PP: 15| Priority 0| Status

### Digital Edge 

Flareon @ Focus Sash

Ability: Flair Hax

EVs: 252 Atk / 4 SpD / 252 Spe  
Adamant Nature  
- Icicle Crash  
- Iron Head  
- U-turn  
- Sacred Hax 

Sacred Hax: Psychic Type | Physical move | 150 Base Power |PP: 15| Additional Effect: 40% Chance too burn the target | Animation: Bolt Strike|Priority:0

Flair Hax: Mega Hax Serene Grace +  Protean

### Theswordbreaker
Arceus-Dragon @ Draco Plate

Ability: No Guard + Shadow Tag

EVs: 248 HP / 252 SpA / 8 SpD 

Modest Nature

IVs: 0 Atk  
- Spacial Rend  
- Focus Blast  
- Blizzard  
- Wait and Hope
 
Wait and Hope Flying Type |Special Move|Priority:0|Base Power: 100|Effect just like Fly tow turns, 30% chance to Paralyze the target|PP: 20|Animation:Sky Attack|Accuracy:100

### Loominite
Giratina-Origin @ Griseous Orb

Ability: The UnderLord

 
Shiny: Yes  
IVs: 0 Atk  
- Will-O-Wisp  
- Shadow Ball  
- Dragon Pulse  
- The Loom Effect
Move Info: Dragon Type | Special Attack | Base: 100 | Accuracy: 100% | Max PP: 15 | Boosts Def & Sp.Def by 2x, Heals 40% of the damage done | Bolt Strike Effect

The Underlord: Ability Info: Changes type that is weak/immune to  the opponent's Pokemon after hit. 10% chance to burn when physically hit.

### OriolesFan52
Feraligatr @ Life Orb

Ability: Aquify

Shiny: Yes  

EVs: 252 Atk / 4 SpD / 252 Spe  
Jolly Nature  
- Extreme Speed 
- Dragon Dance  
- Ice Punch  
- Bone Crushing Death Roll     

Aquify: Turns all normal type moves into water type and gives them 1.5x power   

Bone Crushing Death Roll: Normal Base 120 power 100% chance to lower opponents defense and sp. def by 1 stage 16 pp 100% acc. 25% chance to ohko   


### BBgun999
Goodra @ Rocky Helmet

Ability: Big Bullet Gun 

EVs: 252 HP / 4 Def / 252 SpD  

Naughty Nature  
- Draco Meteor  
- Overheat  
- Close Combat
- Power Lick (custom) 

Power Lick( Drains 1/8 of health and a 10% to paralyze or make the opponent sleep and a 30% to raise one random stat.

Big Bullet Gun (Contrary | make Close Combat a special move instead of physical |+3 Def on switch in |+ 3 SpD on switch in)


### Dragitbot
Draitni @ Leftovers 

Ability: Hidden 

EVs: 252 HP / 252 Def / 4 SpD 

Bold Nature  
IVs: 0 Atk  
- Swords Dance  
- Agility  
- Nasty Plot
- Super Switch

Hidden: Gets a Substitute on switch in

Super Switch: Raises Def and SpD by 1 stage then Baton Pass| Priority 5| PP 5

### Eternal Mayhem
Kyurem-Black @ Life Orb

Ability: Breakthrough

EVs: 252 Spe / 252 Atk / 4 SpA

Lonely Nature
- Fusion Bolt
- Ice Beam
- Outrage
- Dragon Sympony

### Flareon Driod
Flareon @ Charcoal

Ability: Slowchat

EVs: 252 Atk / 252 Spe / 252 HP

Jolly Nature
- V-Create
- Belly Drum
- Recover
- BANHAMMAH

Slowchat:
BANHAMMAH: Status Move| Effect: Same as Roar| Priority +7| PP 5

### Flygonerz
Flygon @ Focus Sash

Ability: Tough Bounce

EVs: 252 Atk / 252 Spe / 4 HP
- Outrage
- Thousand Arrows
- Extreme Speed
- Dragon Shift

Tough Bounce:
Dragon Shift: Boosts Atk by 3 Stages, Defence by 1 Stage, Speed by 2	stages, SpD by 1 stage and uses Wish| Status Move

### BatterBotto
Dragonite @ Iron Ball

Ability: Protean

EVs: 252 Atk / 252 Spe / 4 SpD
- High Jump Kick
- Extreme Speed
- V-Create
- Massacare

Massacre: Priorty +3| Base Power 250| Additional Effect| The user faints after using it| Dragon Type| Physical

### Shivam Rustagi
Giratnia @ Leftovers

Ability: Bad Dreams

EVs: 252 SpA / 252 SpD / 4 SpD
Adamant Nature
- Shadow Ball
- Dragon Pulse 
- Dream Eater
- Secret Killer

Secret Killer: 

### Elcrest
Dratini @ Unknown Sash

Ability: Water Change

EVs: 252 Atk / 252 Spe / 4 HP

Nature
- Dragon Dance
- Outrage
- Rain Dance
- Turbulence

Water Change:
Turbulence: Physical| Flying Type|60 Base Power|100% Accuracy| Priority +1|

### ClassyZ
Scizor-Mega @ Scizorite

Ability: Technician + Simple

EVs: 252 Atk / 252 HP / 4 SpD

Adamant Nature
- Swords Dance
- Mach Punch 
- Bullet Punch 
- Hyperspeed Punch

Hyperspeed Punch: Bug Type| 100% Accuracy| Physical Type| Base Power 45| Priority +2

### OutrageousBoT
Gyarados @ Life Orb

Ability: Dragon Fury

EVs: 252 SpA / 252 Spe / 4 HP

Jolly Nature
- Outrage
- Dragoon Dance
- Draco Meteor
- Raging Lake

Dragon Fury: 

Raging Lake:

### flufi 

![flufi](http://www.smogon.com/dex/media/sprites/xy/raichu.gif)  
Raichu @ Life Orb  
Ability: Static Boost  
EVs: 188 HP / 252 SpA / 64 Spe  
Modest Nature

- Thunder
- Draco Meteor
- Focus Blast
- Mythic Form 

**Static Boost:**on switch-in, raichu gains the ability of magnet rise and gets +1 in every stat including accuracy and evasion  
Mythic Form:custom attack: mythic form type: dragon status move accuracy: null power: null adds dragon to raichu's type, so it should be electric/dragon after gains +1 speed

### Winona 
  
  ![Winona](http://www.smogon.com/dex/media/sprites/xy/exeggutor-alola.gif)      
Alolan-Exeggutor @ Sitrus Berry  
  Ability: Dank Zone  
  EVs: 252 HP / 252 SpA / 252 SpD / 252 Def  
  Quiet Nature Nature
  
- Ice Hammer
- Dragon Hammer
- Wood Hammer
- Super Duper Wombo Comco  

**Dank Zone:**dank zone : triggers trick room, grassy terrain and sunny day.  
**Super Duper Wombo Combo:** dragon type , status move , Accuracy: 100%, pp:5 , effect : use nature power, weather ball, splash and belly drum , animation: like revelation dance , priority: 0
 
### The True Falcon  
 ![Falcon](http://www.smogon.com/dex/media/sprites/xy/samurott.gif)  
 Samurott @ Assault Vest 
Ability: Ultra Technical
EVs: 252 HP / 252 Atk / 4 Def
Adamant Nature 
 
- Waterfall
- Ice Punch
- Secret Sword
- Heroic Beatdown     
**Ultra Technical:**  
**Heroic Beatdown:**
