'use strict'
exports.BattleFormatsData = {

buzzasoarmega: {
requiredItem: "Buzzasoarite",
tier: "OU",
}, 
magzormega: {
requiredItem: "magzorite",
tier: "OU",
}, 
	reapthermega: {
requiredItem: "Reaptherite",
tier: "OU",
	},
scyanidemega: {
requiredItem: "Scyanideite",
tier: "OU",
}, 
	scypsymega: {
requiredItem: "Scypsyite",
tier: "OU",
}, 
	alunixmega: {
requiredItem: "Alunixite",
tier: "OU",
}, 
	coffilixmega: {
requiredItem: "Coffilixite",
tier: "OU",
}, 
crystixmega: {
requiredItem: "Crystixite",
tier: "OU",
}, 
	gemelixmega: {
requiredItem: "Gemelixite",
tier: "OU",
}, 
	scarixmega: {
requiredItem: "Scarixite",
tier: "OU",
}, 


};
