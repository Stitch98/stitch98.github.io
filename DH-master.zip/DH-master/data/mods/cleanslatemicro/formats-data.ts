export const BattleFormatsData: {[k: string]: ModdedSpeciesFormatsData} = {
	typenull: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	crobat: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	galvantula: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	dugtrioalola: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	ludicolo: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	rotom: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	torterra: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	dragalge: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	ninetales: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	pupitar: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	farfetchd: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	purugly: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	kyurem: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	rotomwash: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	umbreon: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	heracross: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	magearna: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	rotommow: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	malamar: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	wailord: {
		tier: "CSM",
		doublesTier: "DOU",
	},
	rotomheat: {
		tier: "CSM",
		doublesTier: "DOU",
	},
};