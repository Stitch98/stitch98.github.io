'use strict';

exports.BattleFormatsData = { //

	 mewtwoshadow: {
		  tier: "OU",
	 },
	 mewtwoshadowburst: {
		  tier: "OU",
	 },
	 marisakirisame: {
		  tier: "OU",
	 },
	 deathwing: {
		  tier: "OU",
	 },
	 niko: {
		  tier: "OU",
	 },
	 sayori: {
		  tier: "OU",
	 },
	 sayorihanged: {
		  tier: "OU",
	 },
	 demigodofrock: {
		  tier: "OU",
	 },
	 sora: {
		  tier: "OU",
	 },
	 bigrig: {
		  tier: "OU",
	 },
	 bigrigforwards: {
		  tier: "OU",
	 },
	 norn: {
		  tier: "OU",
	 },
	 pepsiman: {
		  tier: "OU",
	 },
	 heavy: {
		  tier: "OU",
	 },
	 reimuhakurei: {
		  tier: "OU",
	 },
	 crow: {
		  tier: "OU",
	 },

};
