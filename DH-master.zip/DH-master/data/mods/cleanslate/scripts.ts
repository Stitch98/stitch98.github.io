export const BattleScripts: {[k: string]: ModdedBattleScriptsData} = {
	inherit: 'gen7',
};
