# Avatars directory

You can specify custom avatars for users in `config/config.js` using the `customavatars` option. After doing so, place your custom avatar files in this directory.

Your server must be registered in order to use custom avatars.
